/**
 * Created by Tarnos on 2016-12-26.
 */

lotfw.factory('Options', function(Game){
    var game = Game;
        game.options = {

        };
    return game;
});