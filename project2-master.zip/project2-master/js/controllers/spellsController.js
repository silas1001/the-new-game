/**
 * Created by Tarnos on 2016-12-26.
 */

lotfw.controller('SpellsController', function($scope, Player){

});